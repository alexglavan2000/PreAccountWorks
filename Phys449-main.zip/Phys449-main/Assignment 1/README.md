# PHYS449

## Dependencies

- json
- numpy

## Running `main.py`

To run `main.py`, use

```sh
python main.py
```
